layerName=$1
environment=$2
backendResourceGroupName=$3
backendStorageAccountName=$4
backendContainername=$5
buildRepositoryName=$6
basedOnStratumKitName=$7
layerType=$8
layerDestroy=$9
kitPath=${10}
provider=${11}
inputFile=${12}

echo "Apply me, hello world $layername"
az aks get-credentials --admin --resource-group [__resource_group_name__] --name [__aks_cluster1_name__]
echo "Nodes:"
kubectl get nodes
echo "Pods (default namespace):"
kubectl get pods -n default
helm list -A
# echo "Example from-repo nginx install." 
# echo "IF USING A HELM LAYER YOU DO NOT NEED SOMETHING LIKE THIS."
# helm repo add nginx-stable https://helm.nginx.com/stable
# helm repo update
# helm install nginx-ingress-controller nginx-stable/nginx-ingress
