#!/bin/bash

# -----------------------------------------------------------------------------
# .SYNOPSIS
#   This bash script will fetch the ACR Custom DNS Config IP addresses and
#   add it as ARecords to the DNS Zone specified
# ------------------------------------------------------------------------------

while getopts v:s:a:p:l:i:g: option
do
    case "${option}"
    in
        v) pls_vnet_name=${OPTARG};;
        s) pls_subnet_name=${OPTARG};;
        a) pls_auto_approval_subscription_ids=${OPTARG};;
        p) pls_visibility_subscription_ids=${OPTARG};;
        l) aks_lb_rg=${OPTARG};;
        i) ingress_lb_pls_name=${OPTARG};;
        g) ingress_lb_pls_rg=${OPTARG};;

    esac
done

# Check parameters ------------------------------------------------------------
if [ -z "$pls_vnet_name" ];
then
    echo "Error! pls_vnet_name is null" 1>&2
    exit 64
fi
if [ -z "$pls_subnet_name" ];
then
    echo "Error! pls_subnet_name is null" 1>&2
    exit 64
fi
if [ -z "$pls_auto_approval_subscription_ids" ];
then
    echo "Error! pls_auto_approval_subscription_ids is null" 1>&2
    exit 64
fi
if [ -z "$pls_visibility_subscription_ids" ];
then
    echo "Error! pls_visibility_subscription_ids is null" 1>&2
    exit 64
fi
if [ -z "$aks_lb_rg" ];
then
    echo "Error! aks_lb_rg is null" 1>&2
    exit 64
fi
if [ -z "$ingress_lb_pls_name" ];
then
    echo "Error! ingress_lb_pls_name is null" 1>&2
    exit 64
fi
if [ -z "$ingress_lb_pls_rg" ];
then
    echo "Error! ingress_lb_pls_rg is null" 1>&2
    exit 64
fi
# end of Check parameters ------------------------------------------------
# Function Definitions ---------------------------------------------------


# Create PLS for ingress LB
echo "rg = $aks_lb_rg"
echo "front_id=$(az network lb frontend-ip list --lb-name kubernetes-internal --resource-group $aks_lb_rg --query "[].{name:id}" --output tsv)"

front_id_1=$(az network lb frontend-ip list --lb-name kubernetes-internal --resource-group $aks_lb_rg --query "[].{name:id}" --output tsv)
echo $front_id_1

echo "az network private-link-service create -g $ingress_lb_pls_rg -n $ingress_lb_pls_name --vnet-name $pls_vnet_name --subnet $pls_subnet_name --lb-frontend-ip-configs $front_id_1 --subscription $pls_auto_approval_subscription_ids --visibility $pls_visibility_subscription_ids"
az network private-link-service create -g $ingress_lb_pls_rg -n $ingress_lb_pls_name --vnet-name $pls_vnet_name --subnet $pls_subnet_name --lb-frontend-ip-configs $front_id_1 --subscription $pls_auto_approval_subscription_ids --visibility $pls_visibility_subscription_ids
