# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Added the ability to enable Terraform debugging [#668719](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/668719)

## 2021-07-09 [2.11.0]
### Added
- Numerous variable format updates utilizing concatenization of other top-level variables to construct names adhering to naming standards.
- Numerous comments added that provide instruction on what to change for successful kit deployment, with examples provided. 

### Changed
- Updates to layer versions used in pipeline to resolve dependency defects and layer defects. 

## 2021-05-18 [2.10.0]
### Added
- Support for node_taints and node_labels on the AKS cluster default node pool and additional node pools. Note that for the default pool the only taint allowed is ["CriticalAddonsOnly=true:NoSchedule"] Additional information can be found here: https://docs.microsoft.com/en-us/azure/aks/use-system-pools#system-and-user-node-pools
- add orchestrator_version for node pools allowing for K8s version update.
- Created variable to enable/disable kube dashboard and set default to disabled, as newer AKS versions do not support the dashboard. 

## 2021-03-16 [2.9.0]

### Changed

- Code update in Jumpstart AKS Kit for new variables/tokens [#446689](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/446689)

## 2021-03-09 [2.8.0]

### Added

Added support/configuration for Azure Monitor Private Link Scope (AMPLS). azmonitor_privatelink_scope layer tfvars added, updates made to privatednszone and privateendpoints related to the addition.

### Changed

Azure Monitor layer version in Pipeline.dev.yaml changed to 1.0.0.

## 2021-02-10 [2.7.0]

### Added

- The kit now supports the use of MSI or SPN for ADO agent pools, via the useMsi = true/false variable in Variables.yaml. The default and preferred choice is `true`. Note that the object id of the MSI is _required_ in the kevault tfvars file, as noted in the README and prior CHANGELOG.
- The kit now includes an example Custom Bash layer. This layer has a one-liner example of a kubectl command. This bash layer was added to show how non-tf and non-helm steps can be introduced into the layer sequence easily. As many custom bash shell script layers could be added as needed, between any of the AKS Helm Layers. There are of course many other possible uses. Look at the custom_bash layer's README for more information. The example script for this kit is found in the file var-custom_bash_kubectl.apply.sh.

## 2020-11-18 [2.1.0]

### Changed

Layer versions in Pipeline.dev.yaml and Pipeline.prod.yaml updated to latest major or minor versions.

### Added

KitPath variable added. Allows override if kit is stored anywhere other than root in repo.
Provider type added to Layer entries in Pipeline.dev.yaml.

## [2.3.0] 2020-12-14

### Changed

- Add qetza.replacetokens task to Jumpstart-AKS [#341211](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/341211)

## [2.2.0] 2020-12-10

### Added

- Added a loadbalancer and PLS layer. These are not provided with any configuration specific to AKS at this point, merely included "in working order" as templates.

## [2.1.0] 2020-11-10

### Changed

Fix for some values required even when they would not be needed/used. Specifically variables needed when AAD integration is true but managed=false.
When managed=true, these variables' values should not matter or "null" should be acceptable.

The Kit and its layers now use MSI rather than SPN. Your ADO agent pool must have an MSI or the pipelines and layers will fail, complaining about authentication, missing service principal, etc.

SPN support is DISABLED in this version of the kit and the associated layers. (the variables are commented out and/or removed) If you wish to use SPN, use an earlier version of the kit or modify/customize the scripts and the layers.

## 2020-10-20

### Changed

Fix for custom Helm Provider layers created by kit users.

New layer versions with this fix are:
aks_nginx_ingress: 0.3.0
aks_linkerd: 0.3.0
aks_kured: 0.3.0
aks_akv2k8s: 0.4.0
aks_aad_pod_identity: 0.4.0

## 2020-10-13

### Added

- var-aks.tf (role assignment for aks cluster) and var-privateendpoints.tf (creation of A records for the ACR's private endpoint (PE).

### Changed

- Moved PE logic from var-aks.auto.tfvars to var-privateendpoints.auto.tfvars.

## 2020-09-24

### Added

- Example deployment yaml file, example network policy.
- Layers added to kit for aad pod identities, akv2k8s, kured, linkerd, and nginx ingress controller.

## [1.1.0] - 2020-09-03

#### Added

- Support AKS-managed Azure Active Directory integration [#178241](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_workitems/edit/178241)

## [1.0.0] - 2020-08-20

### Added

- Initial Commit and conversion from Common Library to Stratum
