# jumpstart-aks

[[_TOC_]]

# Azure Naming & Tagging Standards
Azure Resource Groups and resources should follow a common naming convention for consistency and ease of use for application teams. RGs may be defined for different environment types, application tiers and Azure regions.
Ref: [**Azure Naming and Tagging Strategy**](https://att.sharepoint.com/:w:/r/sites/PublicCloud/_layouts/15/Doc.aspx?sourcedoc=%7BAFD449C3-6BC0-4323-88AC-42C45877BCF0%7D&file=Azure%20Naming%20and%20Tagging%20Strategy%20Document%20v1.5.docx&action=default&mobileredirect=true)

  ## Resource Group
    Azure restrictions:
    · Must be unique within subscription, Length 1-64 characters & Case-insensitive
    · It can contain only alphanumeric characters and - _ ( ) . The name cannot end with a period
    Format: app acronym-region-env -app-tier -rg-optional instance identifier
    Examples:
          * {motsID}-eastus2-prod-app-rg
          * {motsID}-westus2-dev-db-rg-01
          * {motsID}-westus2-dev-bkup-rg
  ## Azure Key Vault
     KV name must be globally unique and must be a 3-24 character string, containing only 0-9, a-z, A-Z
     Examples: 
         * {motsID}-eastus2-prod-kv
  ## Storage account
     KV name must be globally unique and must be a 3-24 character string, containing only 0-9, a-z, A-Z with out special characters (,.#@/\[]?&)
     Examples: 
         * {motsID}eastus2prodappst
  ## Log Analytics Workspace
     LAW name must be globally unique and must be a 3-24 character string, containing only 0-9, a-z, A-Z
     Examples: 
         * {motsID}-eastus2-prod-app-law
  ## Azure Region Designator
    Abbreviation    Location
      eastus         east US
      eastus2        east US2
      westus         west US
      westus2        west US2
      centus         central US
  ## Environment Types
    The environment tier designator will be 2 to 4 characters to differentiate between the various environments as part of lifecycle of an application or service. Examples include:
    Abbreviation    Tier
      prod          production
      nprd          non-prod
      stge          staging / pre-prod
      dev           dev
      test          test
      qa            quality assurance
      perf          performance
      uat           user acceptance test
      trn           training
  ## Application Tier
    The instance type or application tier will be 2 to 4 characters to indicate the application tier of the service. Examples include:
    Abbreviation    Instance Type / Application Tier
      
        web          web server / front end
        app          application server
        db           database server
        jump         jump vm
        fw           firewall
        log          logging
        bkup         backups
        gen          general use
        infr         infra/networking
        mgmt         management
        dmz          internet facing

      Suffix     Cloud Resource Type
       -vm         virtual machine
       -vmss       virtual machine scale set
       -rg         resource group
       -nsg        network security group
       -vnet       virtual network
       -snet       subnet
       -pe         private end point
       -pls        private link service
       -os         Managed disk (OS)
       -data       Managed disk (Data)
       -as         availability set
       -ai         application insights
       -kv         key vault
       -func       function
       -st         storage account
       -lb         load balancer
       -lbprb      load balancer health probe
       -lbbep      load balancer backend pool
       -lbr        load balancer rules
       -law        log analytics workspace
       -rt         route (as per UDR)
       -rsv        recovery services vault (ASR)
       -agw        application gateway


# Kit Description
For information on how to use Stratum-based kits, such as adding and removing layers, deploying multiple layers of the same resource type, composing custom layers, and more; see [Stratum Kits Wiki](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_wiki/wikis/DevOps%20Automation/1467/Understand-layers-workflow).

## This kit contains layers:
- Resource Group
- Virtual networks, subnets, network security groups
- Log Analytics Workspace
- Storage account
- Key Vault
- Key Vault Diagnostics
- Azure Kubernetes Services
- Load balancer
- NSG flow logs
- Private endpoints
- Private DNS Zone
- Private DNS Records
- Private Link Service
- AKS Alerts
- AKS Dashboards
- AKS Workbooks
- AKS AAD Pod Identities
- AKS AKV2K8S
- AKS Kured
- AKS Linkerd
- AKS Nginx Ingress Controller
- Custom Bash Example Layer

# Pre-requisites
- Service connection to the ACC-Azure-00 Stratum artifact feed
    - Project Settings -> Service Connections -> New Service Connection -> Azure Repos/Team Foundation Server
    - Connection URL: https://dev.azure.com/ACC-Azure-00
    - Personal Access Token: Token with "Packaging Read" access
    - Service Connection Name: ACC-Azure-00 Stratum Feed
- Separate service connections to required subscriptions
- [DevOps Onboarding Services (contains storage account for state)](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_git/att-onboarding-devops-services?path=%2FREADME.md&_a=preview)
- [Image Builder pipeline (if using custom images)](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_git/jumpstart-image-builder-sig?path=%2FREADME.md&_a=preview)
- A container in the state storage account
- ADO agent MSI has storage account key operator role on the storage where state is saved

## Preparing Kit
1. Download the kit version from the [artifact feed](https://dev.azure.com/ACC-Azure-00/Stratum).  The download command will be on the overview page of the artifact you choose.  You may need to set your proxy to use the CLI, including some possible updates to python via cmd.exe
    * "C:\Program Files (x86)\Microsoft SDKs\Azure\CLI2\python" -m pip install --upgrade pip
    * "C:\Program Files (x86)\Microsoft SDKs\Azure\CLI2\Scripts\pip" install python-certifi-win32
    * set http_proxy=http://sub.proxy.att.com:8080
    * set https_proxy=http://sub.proxy.att.com:8080
    * set AZURE_CLI_DISABLE_CONNECTION_VERIFICATION=1
1. Create a repo for your application in your ADO organization
1. Add the Layers and Pipelines folders to your repo
1. Modify the files below

**NOTE: Only the kit must be downloaded.  Layers do not need to be downloaded as they will be retrieved as your pipeline runs**

# Step-by-Step: Minimum variables to change to deploy
To deploy this kit on first attempt, the following modifications are required: No need to worry about *.tfvars and .tf files only need to update variable values in Variables.yaml and Variables.{env}.yaml files.
**Note: replace 'change_me' values in variables.yaml and variables.dev.yaml files.**

## Variables.yaml
1. motsId
1. agent_pool - Name of the ADO agent pool (see: pre-reqs)
1. projectName - Name of the ADO project for this deployment
1. pipelineId - The pipeline ID of image builder (if using IB)
1. artifactFeedCredentials - PAT based service connection name to the artifact feed (see: pre-reqs)
1. useMsi - true or false depending on whether you are using a managed identity for your ADO agent pool (preferred)
terraformDebug
1. terraformDebug - true or false depending on whether you want to enable Terraform debugging
1. terraformDebugType - set to "TRACE" or left blank ("") depending on whether you want to enable Terraform debugging

## Variables.dev.yaml
Variable.dev.yaml file has in-detail naming standards along with examples and following variable values modification should be enough to deploy AKS infrastructure. Don't worry about other files and variables. See above "kit description" to get resources list in this kit.
* serviceConnectionApp - Service connection name to env subscription -> (line 3)
* backendResourceGroupName - Resource Group where storage account containing Terraform state resides -> (line 7)
* backendStorageAccountName - Storage account where Terraform state will reside -> (line,. 9)
* ado_resource_group_name - ADO onbaording resource group name -> (line. 15)
* ado_vnet_name - ADO onboarding Vnet name -> (line. 17)
* ado_subnet_name - ADO onboarding subnet name -> (line 19)
* ado_subscription_id - ADO onboarding subscription id -> (line 21)
* ado_key_vault_name - ADO onboarding kv name -> (line 23)
* acr_name - ADO onboarding Azure container registry name -> (line 25)
* created_by - Created by attID or SPN name -> (line 29)
* contact_dl - App Team contact dl -> (line 31)
* env - environment name. Predefined env values are dev,prod,nprd,stge,test,qa,perf,uat,trn,poc,dr -> (line 33)
* automated_by - automated by attid or terraform -> (line 35)
* location -  location of infrastructure provisioning. Default value is eastus2 -> (line 37)
* app_tier -  -> (line 39)

* msi_object_id - MSI object of Agent pools. This value can be found in the portal by searching for your ADO agent's MSI name in AAD and copying the Object ID from there. The command: az ad sp list --display-name <ADOMSINAME> --output tsv | awk '{print $19}' will show it if run from the Azure Cloud Shell, where <ADOMSINAME> is the display name of the MSI.   -> (line 48)
* aks_version - AKS cluster version -> (line 51)
* aks_node_size - AKS cluster node size. default value is "Standard_B2ms" -> (line 54)
* aad_group_id - Azure Active Directory group object id to grant RBAC access to AKS cluster -> (line 57)
* subscription_id - Subscription id where trying to provision infrastructure -> (line 60)
* Remove resources block where noted if not planning to use Image Builder on first deployment

## Pipeline.dev.yaml
1. Remove resources block where noted if not planning to use Image Builder on first deployment
Note: One of the open issue is that After successful run of netwroking layer, when rerun the pipeline then subnet and Private end points are recreating. So when rerunning the pipeline "skip" networking layer.

        - name: networking
          type: networking
          version: "1.1.0"
          skip: false                ## when rerun skip: true
          provider: terraform
          destroy: false
          dependencies:
            resourcegroup: resourcegroup

# Adding and Removing Layers
## Adding
1. Identify the layer and version you wish to add
1. Add an object to the layer parameters in Pipeline.env.yaml
1. Use the examples auto.tfvars file included with the layer as a starting point
1. Name the auto.tfvars file the same as the layer name ie: var-<layername>.auto.tfvars

## Adding multiple layers of the same type
Multiple layers of the same type can be added by setting the layer name attributes in Pipeline.env.yaml.  This example deploys two resource group layers with one network layer dependent.  Note the dependencies for the networking (myrg1: resourcegrup).  **When a layer has a custom name, there must be a matching variable file (var-myrg1.auto.tfvars instead of var-resourcegroup.auto.tfvars)**

    name: myrg1
    type: resourcegroup
    version: "0.0.1"
    skip: false
    dependencies:
      start: start

    name: myrg2
    type: resourcegroup
    version: "0.0.1"
    skip: false
    dependencies:
      start: start

    name: networking
    type: networking
    version: "0.0.1"
    skip: false
    dependencies:
      myrg1: resourcegroup

## Removing layers
1. Remove the reference from Pipeline.env.yaml
1. Delete the matching auto.tfvars file
**Note: Removing a layer does not destroy the resource**

# Skipping Layers
There are two ways to skip layers.  These exist to focus troubleshooting efforts.

## Setting skip: true
Each layer has a "skip: false" by default.  When setting this to true, the stage will still run however Terraform will not execute.  If skipping the first layer (usually resourcegroup), "start: start" must be placed in the first layer that is not skipped.  Since resourcegroup is a fast layer and automatic skip detection will not attempt to apply, it is usually recommended to leave the first layer as skip: false.

## Automatic Skip Detection
When the Terraform plan stage does not detect any changes, the apply stage will not execute any Terraform commands.  The stage will still run, however Terraform plan is skipped.  This is not optional

## Note
A value for variable auto_scaler_profile is optional, and is only needed if changing the cluster default scaling options. 